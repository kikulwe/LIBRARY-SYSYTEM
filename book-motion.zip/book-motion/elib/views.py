from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request,'home.html')

def  login(request):
     return render(request,'login.html')

def  librarian(request):
     return render(request,'Librarian signup.html')

def  student(request):
     return render(request,'student signup.html')     